﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");

            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person"); ;
            var documents = person.Find(new BsonDocument()).ToList();

            DataTable table = new DataTable();
            table.Columns.Add("Name");
            table.Columns.Add("Age");
            table.Columns.Add("Email");
            table.Columns.Add("Password");
            table.Columns.Add("Job");

            foreach (BsonDocument doc in documents)

            {
                var name = "";
                var email = "";
                var password = "";
                var job = "";
                var age = "";
                //int age=0;

                if (doc.Contains("name")) name += doc.GetValue("name");
                if (doc.Contains("age")) age += doc.GetValue("age");
                //if (doc.Contains("age")) age = doc.GetValue("age").ToInt32();
                if (doc.Contains("email")) email += doc.GetValue("email");
                if (doc.Contains("password")) password += doc.GetValue("password");
                if (doc.Contains("job")) job += doc.GetValue("job");
               
                table.Rows.Add(name,age,email,password, job);
                

            }

            DataGrid1.DataSource = table;
            DataGrid1.DataBind();

            //Response.Redirect("~/webForm1.aspx?reload=1");
        }
    }
}
