﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Collections.ObjectModel;

namespace WebApplication5
{
    public partial class WebForm1 : System.Web.UI.Page

    {
        protected void Page_Load(object sender, EventArgs e)
        {

            


        }
        protected void Submit_Click(object sender, EventArgs e)
        {

            welcome.Text = "your data is saved on our database aws, ja ja ja";

            showinfo.Text = namebox.Text + " " + famnamebox.Text;



            if (agebox.Text != "" && Convert.ToInt32(agebox.Text) > 0)
            {
                if (Convert.ToInt32(agebox.Text) > 17)
                    showage.Text = namebox.Text + " user's age is (adult) " + agebox.Text;
                else
                { showage.Text = namebox.Text + " user's age is (not adult) " + agebox.Text; }



                if (unemployedcheckbox.Checked == true && Convert.ToInt32(agebox.Text) > 11)
                {
                    

                   
                    showunemployed.Text = "So, you checked unemployed, your " + namebox.Text + " user's NEW age is " + (Convert.ToInt32(agebox.Text) - 10).ToString();
                }

            }



        }
    }
}