﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");

            var dbList = dbClient.ListDatabases().ToList();

            //Console.WriteLine("The list of databases on this server is: ");

            var listaux = "";

            foreach (var db in dbList)
            {
                //Console.WriteLine(db);
                listaux = listaux + db.ToString() + "<br>";
            }

            list.Text = listaux;

            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person");

            var documents = person.Find(new BsonDocument()).ToList();

            var listaux2 = "";
            foreach (BsonDocument doc in documents)
            {
                listaux2 = listaux2 + doc.ToString() + "<br>";
            }

            list2.Text = listaux2;
        }
    }
}