﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var person = Connect();
            var listaux2 = "";
            foreach (BsonDocument doc in person)
            {
                //array
                ListBox1.Items.Add((string)doc.GetValue("name", null));
                listaux2 = listaux2 + doc.ToString() + "<br>";
            }

            ListBox1.DataBind();
            list2.Text = listaux2;

        }

        protected void Submit_Button_Click(object sender, EventArgs e)
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");

            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person");
            var filter = Builders<BsonDocument>.Filter.Eq("name", ListBox1.SelectedValue);
            person.DeleteOne(filter);
            Response.Redirect("~/webForm2.aspx?reload=1");

        }

        public static IEnumerable<BsonDocument> Connect()
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");

            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person"); ;
            var documents = person.Find(new BsonDocument()).ToList();
            return documents;


        }

       


    }
}