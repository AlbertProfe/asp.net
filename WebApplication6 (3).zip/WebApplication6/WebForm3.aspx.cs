﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var person = Connect();
            var listaux2 = "";

            foreach (BsonDocument doc in person)
            {
                //array

                listaux2 = listaux2 + doc.ToString() + "<br>";

            }


            list2.Text = listaux2;


        }

        protected void Submit_Button_Click(object sender, EventArgs e)
        {
            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");
            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person");

            var filter = Builders<BsonDocument>.Filter.Eq("name", selectednamebox.Text);

            var doc = person.Find(filter).FirstOrDefault();

            if (doc == null)
            {
                isname.Text = "Person NOT found: " + selectednamebox.Text;
            }
            else

            {
                isname.Text = "Person found: " + selectednamebox.Text;

                if (emailbox.Text != "")
                {

                    var updateemail = Builders<BsonDocument>.Update.Set("email", emailbox.Text);
                    person.UpdateOne(filter, updateemail);
                    updatedemail.Text = "Email has been updated to " + emailbox.Text;
                }
                if (passwordbox.Text != "")
                {

                    var updatepassword = Builders<BsonDocument>.Update.Set("password", passwordbox.Text);
                    person.UpdateOne(filter, updatepassword);
                    updatedpassword.Text = "Password has been updated to " + passwordbox.Text;
                }
                if (jobbox.Text != "")
                {

                    var updatejob = Builders<BsonDocument>.Update.Set("job", jobbox.Text);
                    person.UpdateOne(filter, updatejob);
                    updatedjob.Text = "Job has been updated to " + jobbox.Text;
                }
                if (namebox.Text != "")
                {

                    var updatename = Builders<BsonDocument>.Update.Set("name", namebox.Text);
                    person.UpdateOne(filter, updatename);
                    updatedname.Text = "Name has been updated to " + namebox.Text;
                }
            }


        }

        public static IEnumerable<BsonDocument> Connect()
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");
            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person");
            var documents = person.Find(new BsonDocument()).ToList();

            return documents;
        }

    }
}