﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            var person = Connect();

            var listaux2 = "";
            
            
            foreach (BsonDocument doc in person)
            {
                //list toString
                listaux2 = listaux2 + doc.ToString() + "<br>";
            }

            list2.Text = listaux2;
        }

        protected void Submit_Button_Click(object sender, EventArgs e)
        {

            //var person = Connect();

            var doc = new BsonDocument
            {
                {"name", usernamebox.Text},
                {"job", jobbox.Text},
                {"email", emailbox.Text},
                {"password", passwordbox.Text}
            };

            Insert(doc);
            Response.Redirect("~/webForm1.aspx?reload=1");
        }

        public static IEnumerable<BsonDocument> Connect()
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");

            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person"); ;
            var documents = person.Find(new BsonDocument()).ToList();
            return documents;


        }

        public static void Insert(BsonDocument doc)
        {

            MongoClient dbClient = new MongoClient("mongodb+srv://test:MB7ZbkMP6Jnhjrjw@clustertest.0h8fd.mongodb.net/city?retryWrites=true&w=majority");

            IMongoDatabase database = dbClient.GetDatabase("city");

            var person = database.GetCollection<BsonDocument>("person");

            person.InsertOne(doc);

        }

    }

}
